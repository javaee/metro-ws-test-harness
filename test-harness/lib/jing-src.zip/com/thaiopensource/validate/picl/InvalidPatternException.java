package com.thaiopensource.validate.picl;

class InvalidPatternException extends Exception {
}
