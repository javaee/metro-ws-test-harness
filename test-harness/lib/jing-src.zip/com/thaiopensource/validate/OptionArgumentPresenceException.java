package com.thaiopensource.validate;

public class OptionArgumentPresenceException extends OptionArgumentException {
  public OptionArgumentPresenceException() {
  }
}
