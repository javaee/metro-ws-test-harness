package com.thaiopensource.validate;

public class OptionArgumentException extends Exception {
  public OptionArgumentException() {
  }

  public OptionArgumentException(String message) {
    super(message);
  }
}
