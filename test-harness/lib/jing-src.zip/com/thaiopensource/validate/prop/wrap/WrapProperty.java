package com.thaiopensource.validate.prop.wrap;

import com.thaiopensource.validate.NamePropertyId;

public class WrapProperty {
  public static final NamePropertyId ATTRIBUTE_OWNER = new NamePropertyId("ATTRIBUTE_OWNER");

  private WrapProperty() { }
}
