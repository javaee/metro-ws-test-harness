package com.thaiopensource.relaxng.parse;

public interface ParsedNameClass { }
