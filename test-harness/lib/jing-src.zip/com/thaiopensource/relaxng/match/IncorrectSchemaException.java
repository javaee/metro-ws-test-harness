package com.thaiopensource.relaxng.match;

public class IncorrectSchemaException extends Exception {
}
