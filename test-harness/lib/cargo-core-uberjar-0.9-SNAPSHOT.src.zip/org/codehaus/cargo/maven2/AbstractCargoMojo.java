/* 
 * ========================================================================
 * 
 * Copyright 2005-2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * ========================================================================
 */
package org.codehaus.cargo.maven2;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.project.MavenProject;
import org.apache.maven.artifact.resolver.ArtifactResolver;
import org.apache.maven.artifact.factory.ArtifactFactory;
import org.apache.maven.artifact.repository.ArtifactRepository;
import org.codehaus.cargo.container.configuration.ConfigurationType;
import org.codehaus.cargo.container.ContainerType;
import org.codehaus.cargo.maven2.log.MavenLogger;
import org.codehaus.cargo.maven2.util.CargoProject;
import org.codehaus.cargo.maven2.jetty.JettyArtifactResolver;
import org.codehaus.cargo.util.log.FileLogger;
import org.codehaus.cargo.util.log.Logger;

/**
 * Common code used for all cargo mojos.
 *
 * @version $Id: AbstractCargoMojo.java 1158 2006-07-29 10:55:48Z vmassol $
 */
public abstract class AbstractCargoMojo extends AbstractMojo
{
    /**
     * The Maven project.
     *
     * @parameter expression="${project}"
     * @required
     * @readonly
     */
    protected MavenProject project;

    /**
     * Container configuration.
     * <p>
     * Example:
     * <pre><xmp>
     *   <configuration>
     *     <type>standalone</type>
     *     <dir>${basedir}/target/resin</dir>
     *     <properties>
     *       <cargo.servlet.port>8080</cargo.servlet.port>
     *       <cargo.logging>high</cargo.logging>
     *     </properties>
     *     <deployables>
     *       <deployable>
     *         <groupId>war group id</groupId>
     *         <artifactId>war artifact id</artifactId>
     *         <type>war</type>
     *         <properties>
     *           <context>optional root context</context>
     *         </properties>
     *       </deployable>
     *       <deployable>
     *         <groupId>ear group id</groupId>
     *         <artifactId>ear artifact id</artifactId>
     *         <type>ear</type>
     *       </deployable>
     *       [...]
     *     </deployables>
     *   </configuration>
     * </xmp></pre>
     *
     * @parameter
     */
    private Configuration configuration;

    /**
     * Container configuration.
     * <p>
     * Example:
     * <pre><xmp>
     *   <container>
     *     <containerId>resin3x</containerId>
     *     <zipUrlInstaller>
     *       <url>http://www.caucho.com/download/resin-3.0.18.zip</url>
     *       <installDir>${basedir}/target/install</installDir>
     *     </zipUrlInstaller>
     *     <output>${basedir}/target/resin-cargo.log</output>
     *     <append>false</append>
     *     <log>${basedir}/target/resin-log.log</log>
     *   </container>
     * </xmp></pre>
     *
     * @parameter
     */
    private Container container;

    /**
     * Deployer configuration.
     *
     * Example:
     * <pre><xmp>
     *   <container>
     *     <containerId>tomcat5x</containerId>
     *     <type>remote</type>
     *   </container>
     *
     *   <configuration>
     *     <properties>
     *       <cargo.tomcat.manager.url>...</cargo.tomcat.manager.url>
     *       <cargo.tomcat.manager.username>system</cargo.tomcat.manager.username>
     *       <cargo.tomcat.manager.password>password</cargo.tomcat.manager.password>
     *     </properties>
     *   </configuration>
     *
     *   <deployer>
     *     <containerId>tomcat5x</container>
     *     <type>runtime</type>
     *     <deployables>
     *       <deployable>
     *         <groupId>war group id</groupId>
     *         <artifactId>war artifact id</artifactId>
     *         <type>war</type>
     *         <properties>
     *           <context>optional root context</context>
     *         </properties>
     *         <pingURL>optional url to ping to know if deployable is done or not</pingURL>
     *       </deployable>
     *       <deployable>
     *         <groupId>ear group id</groupId>
     *         <artifactId>ear artifact id</artifactId>
     *         <type>ear</type>
     *         <pingURL>optional url to ping to know if deployable is done or not</pingURL>
     *       </deployable>
     *       [...]
     *     </deployables>
     *   </deployer>
     * </xmp></pre>
     *
     * @parameter
     */
    private Deployer deployer;

    //============== Fields used for handling embedded containers ==============================

    /**
     * The component that is used to resolve additional artifacts required.
     *
     * @component
     */
    private ArtifactResolver artifactResolver;

    /**
     * The local repository.
     *
     * @parameter expression="${localRepository}"
     */
    private ArtifactRepository localRepository;

    /**
     * Remote repositories used for the project.
     *
     * @todo this is used for site descriptor resolution - it should relate to the actual project but for some reason they are not always filled in
     * @parameter expression="${project.remoteArtifactRepositories}"
     */
    private List repositories;

    /**
     * The component used for creating artifact instances.
     *
     * @component
     */
    private ArtifactFactory artifactFactory;

    //==========================================================================================

    /**
     * The key under which the container is stored in the plugin context. We store it so that
     * it's possible to get back the same container instance even if this mojo is called in
     * different Maven2 executions. This is required for stopping embedded containers for example.
     */
    public static final String CONTEXT_KEY_CONTAINER =
        AbstractCargoMojo.class.getName() + "-Container";

    private CargoProject cargoProject;

    protected Deployer getDeployerElement()
    {
        return this.deployer;
    }

    protected void setDeployerElement(Deployer deployerElement)
    {
        this.deployer = deployerElement;
    }

    protected Configuration getConfigurationElement()
    {
        return this.configuration;
    }

    protected void setConfigurationElement(Configuration configurationElement)
    {
        this.configuration = configurationElement;
    }

    protected Container getContainerElement()
    {
        return this.container;
    }

    protected void setContainerElement(Container containerElement)
    {
        this.container = containerElement;
    }

    public void execute() throws MojoExecutionException
    {
        if (this.cargoProject == null)
        {
            this.cargoProject = new CargoProject(this.project, getLog());
        }
    }

    protected void setCargoProject(CargoProject cargoProject)
    {
        this.cargoProject = cargoProject;
    }

    protected CargoProject getCargoProject()
    {
        return this.cargoProject;
    }

    protected org.codehaus.cargo.container.configuration.Configuration createConfiguration()
        throws MojoExecutionException
    {
        org.codehaus.cargo.container.configuration.Configuration configuration;

        // If no configuration element is specified create a standalone configuration if the
        // container is of type local and a runtime one if it's of type remote. If no container
        // is specified then the type is local.
        if (getConfigurationElement() == null)
        {
            Configuration configurationElement = new Configuration();

            if (getContainerElement().getType().isLocal())
            {
                configurationElement.setType(ConfigurationType.STANDALONE);
                configurationElement.setHome(new File(getCargoProject().getBuildDirectory(),
                    getContainerElement().getContainerId()).getPath());
            }
            else
            {
                configurationElement.setType(ConfigurationType.RUNTIME);
            }

            setConfigurationElement(configurationElement);
        }

        configuration = getConfigurationElement().createConfiguration(
            getContainerElement().getContainerId(), getCargoProject());

        return configuration;
    }

    private void computeContainerId(Container containerElement)
    {
        // If no container has been specified then default to Jetty 5.x
        if (containerElement.getContainerId() == null)
        {
            containerElement.setContainerId("jetty5x");
            containerElement.setType(ContainerType.EMBEDDED);
        }
    }

    protected org.codehaus.cargo.container.Container createContainer()
        throws MojoExecutionException
    {
        org.codehaus.cargo.container.Container container = null;

        // Try to find the container in the Maven2 context first.
        Map context = getPluginContext();
        if (context != null)
        {
            container = (org.codehaus.cargo.container.Container) context.get(CONTEXT_KEY_CONTAINER);
        }

        if (container == null)
        {
            container = createNewContainer();
        }

        if (context != null)
        {
            context.put(CONTEXT_KEY_CONTAINER, container);
        }

        return container;
    }

    protected org.codehaus.cargo.container.Container createNewContainer()
        throws MojoExecutionException
    {
        org.codehaus.cargo.container.Container container;

        if (getContainerElement() == null)
        {
            // Only accept default configuration if the packaging is not of type EAR as Cargo
            // currently doesn't have an embedded container that supports EAR (we need to add
            // openEJB support!).
            if ((getCargoProject().getPackaging() != null)
                && !getCargoProject().getPackaging().equalsIgnoreCase("war"))
            {
                throw new MojoExecutionException("For all packaging other than war you need to "
                    + "configure the container you wishes to use.");
            }

            Container containerElement = new Container();
            computeContainerId(containerElement);

            getLog().info("No container defined, using a default ["
                + containerElement.getContainerId() + ", " + containerElement.getType().getType()
                + "] container");

            setContainerElement(containerElement);
        }

        // If no container id is specified, default to Jetty 5.x Embedded.
        if (getContainerElement().getContainerId() == null)
        {
            computeContainerId(getContainerElement());
        }

        if (getContainerElement().getType() == ContainerType.EMBEDDED)
        {
            loadEmbeddedContainerDependencies();
        }

        container = getContainerElement().createContainer(createConfiguration(),
            createLogger(), getCargoProject());

        return container;
    }

    protected void loadEmbeddedContainerDependencies() throws MojoExecutionException
    {
        if (getContainerElement().getContainerId().startsWith("jetty"))
        {
            JettyArtifactResolver resolver = new JettyArtifactResolver(this.artifactResolver,
                this.localRepository, this.repositories, this.artifactFactory);
            ClassLoader classLoader =
                resolver.resolveDependencies(getContainerElement().getContainerId());
            getCargoProject().setEmbeddedClassLoader(classLoader);
            Thread.currentThread().setContextClassLoader(classLoader);
        }
    }

    protected org.codehaus.cargo.container.deployable.Deployable createAutoDeployDeployable(
        org.codehaus.cargo.container.Container container) throws MojoExecutionException
    {
        Deployable deployableElement = new Deployable();
        return deployableElement.createDeployable(container.getId(), getCargoProject());
    }

    protected boolean containsAutoDeployable(Deployable[] deployableElements)
    {
        boolean found = false;

        for (int i = 0; i < deployableElements.length; i++)
        {
            Deployable deployableElement = deployableElements[i];
            if (deployableElement.getGroupId().equals(getCargoProject().getGroupId())
                && deployableElement.getArtifactId().equals(getCargoProject().getArtifactId()))
            {
                found = true;
                break;
            }
        }

        return found;
    }

    /**
     * Create a logger. If a <code>&lt;log&gt;</code> configuration element has been specified
     * by the user then use it. If none is specified then log to the Maven 2 logging subsystem.
     *
     * @return the logger to use for logging this plugin's activity
     */
    protected Logger createLogger()
    {
        Logger logger;
        if ((getContainerElement() != null) && (getContainerElement().getLog() != null))
        {
            // Ensure that the directories where the log will go are created
            getContainerElement().getLog().getParentFile().mkdirs();

            logger = new FileLogger(getContainerElement().getLog(), false);
        }
        else
        {
            logger = new MavenLogger(getLog());
        }

        if ((getContainerElement() != null) && (getContainerElement().getLogLevel() != null))
        {
            logger.setLevel(getContainerElement().getLogLevel());
        }

        return logger;
    }
}
