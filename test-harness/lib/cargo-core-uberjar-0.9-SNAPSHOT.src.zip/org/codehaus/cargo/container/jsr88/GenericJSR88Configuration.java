/*
 * ========================================================================
 * 
 * Copyright 2005-2006 Vincent Massol.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * ========================================================================
 */
package org.codehaus.cargo.container.jsr88;

import org.codehaus.cargo.container.property.JSR88PropertySet;
import org.codehaus.cargo.container.property.RemotePropertySet;
import org.codehaus.cargo.container.spi.configuration.AbstractRuntimeConfiguration;
import org.codehaus.cargo.container.configuration.ConfigurationCapability;

import java.net.URI;

/**
 * An implementation of the {@link org.codehaus.cargo.container.configuration.RuntimeConfiguration}
 * for a generic JSR88-compliant container.
 *
 * @version $Id: GenericJSR88Configuration.java 1010 2006-05-02 06:54:25Z vmassol $
 */
public class GenericJSR88Configuration extends AbstractRuntimeConfiguration
{
    /**
     * JSR88 configuration capability.
     */
    private static ConfigurationCapability capability = new JSR88ConfigurationCapability();

    /**
     * Creates a <code>GenericJSR88ExistingConfiguration</code> and sets home URI.
     * @param homeURI URI to use when acquiring a {@link DeploymentManager}
     */
    public GenericJSR88Configuration(URI homeURI)
    {
        setProperty(RemotePropertySet.URI, homeURI.toString());
    }

    /**
     * Creates a <code>GenericJSR88ExistingConfiguration</code> and sets home URI,
     * {@link JSR88PropertySet#USERNAME} and
     * {@link JSR88PropertySet#PASSWORD} property.
     * @param uri URI to use when acquiring a {@link DeploymentManager}
     * @param username username to use when acquiring a {@link DeploymentManager}
     * @param password password to use when acquiring a {@link DeploymentManager}
     */
    public GenericJSR88Configuration(URI uri, String username, String password)
    {
        this(uri);
        setProperty(JSR88PropertySet.USERNAME, username);
        setProperty(JSR88PropertySet.PASSWORD, password);
    }

    /**
     * @return the {@link ConfigurationCapability} of the configuration in term of properties it
     *         supports, etc
     */
    public ConfigurationCapability getCapability()
    {
        return capability;
    }


}
