/*
 * ========================================================================
 * 
 * Copyright 2005 Vincent Massol.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * ========================================================================
 */
package org.codehaus.cargo.container.jsr88;

import org.codehaus.cargo.container.deployer.DeployableMonitor;
import org.codehaus.cargo.container.deployable.Deployable;
import org.codehaus.cargo.container.RemoteContainer;
import org.codehaus.cargo.container.property.JSR88PropertySet;
import org.codehaus.cargo.container.property.RemotePropertySet;
import org.codehaus.cargo.container.spi.deployer.AbstractRemoteDeployer;
import org.codehaus.cargo.container.configuration.Configuration;
import org.codehaus.cargo.util.CargoException;

import javax.enterprise.deploy.spi.TargetModuleID;
import javax.enterprise.deploy.spi.DeploymentManager;
import javax.enterprise.deploy.spi.exceptions.DeploymentManagerCreationException;
import javax.enterprise.deploy.spi.factories.DeploymentFactory;
import javax.enterprise.deploy.spi.status.ProgressObject;
import javax.enterprise.deploy.spi.status.ProgressListener;
import javax.enterprise.deploy.spi.status.ProgressEvent;
import javax.enterprise.deploy.shared.factories.DeploymentFactoryManager;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Map;
import java.util.jar.JarFile;
import java.io.IOException;
import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.MalformedURLException;

/**
 * Deployer for JSR88-compliant containers.
 * 
 * @see RemoteContainer
 *
 * @version $Id: JSR88Deployer.java 1160 2006-07-30 13:15:34 -0700 (Sun, 30 Jul 2006) vmassol $
 */
public class JSR88Deployer extends AbstractRemoteDeployer
{
    /**
     * A {@link DeploymentManager} that is used by this {@link JSR88Deployer}.
     */
    private DeploymentManager manager;

    /**
     * {@link Deployable}-to-{@link TargetModuleID}s mapping.
     */
    private Map deployedAs;

    /**
     * @param container a {@link org.codehaus.cargo.container.Container} to create the deployer for
     */
    public JSR88Deployer(RemoteContainer container)
    {
        this(container.getConfiguration());
    }

    /**
     * @param cfg a {@link Configuration} to create the deployer for
     */
    public JSR88Deployer(Configuration cfg)
    {
        String classpathStr = cfg.getPropertyValue(JSR88PropertySet.DEPLOYTOOL_CLASSPATH);
        URL[] classpath = stringToURLArray(classpathStr);
        String jar = cfg.getPropertyValue(JSR88PropertySet.DEPLOYTOOL_JAR);

        if (null == classpath || 0 == classpath.length)
        {
            loadDeploymentFactorylFromJar(jar, new URL[0]);
        }
        else
        {
            loadDeploymentFactorylFromJar(jar, classpath);
        }

        initialize(
            cfg.getPropertyValue(RemotePropertySet.URI),
            cfg.getPropertyValue(JSR88PropertySet.USERNAME),
            cfg.getPropertyValue(JSR88PropertySet.PASSWORD));

        this.deployedAs = new HashMap();
    }

    /**
     * Deploy a {@link Deployable} to the running container and make it available for requests.
     *
     * @param deployable the {@link Deployable} to deploy
     */
    public void deploy(final Deployable deployable)
    {
        //JSR88Deployable myDeloyable = checkCastToJSR88Deployable( deployable );
        final ProgressObject po = this.manager.distribute(this.manager.getTargets(),
            new File(deployable.getFile()), null);

        //Do a non-blocking wait for the deploy operation to complete,
        //then start the deployed application
        po.addProgressListener(new ProgressListener()
        {
            public void handleProgressEvent(ProgressEvent event)
            {
                if (!event.getDeploymentStatus().isRunning())
                {
                    setDeployedAs(deployable, po.getResultTargetModuleIDs());
                    start(deployable);
                }
            }
        });
    }

    /**
     * <p>Deploy a {@link Deployable} to the running container and make it available for requests.
     * Waits for the {@link Deployable} to be fully deployed before returning.
     *
     * <p><b>Note</b>: this operation, specified in terms of JSR-88, means <code>distribute()</code>
     * <i>and</i> <code>start()</code>.
     *
     * @param deployable the {@link Deployable} to deploy
     * @param monitor the monitor that checks for deployment status
     */
    public void deploy(Deployable deployable, DeployableMonitor monitor)
    {
        ProgressObject po = this.manager.distribute(this.manager.getTargets(),
            new File(deployable.getFile()), null);
        blockingWait(po);
        setDeployedAs(deployable, po.getResultTargetModuleIDs());
        start(deployable);
    }

    /**
     * Undeploy a {@link Deployable} from the running container. The service becomes unavailable
     * for requests.
     *
     * @param deployable the {@link Deployable} to undeploy
     */
    public void undeploy(Deployable deployable)
    {
        TargetModuleID[] deployedAS = checkGetDeployedAs(deployable);
        ProgressObject po = this.manager.undeploy(deployedAS);
        blockingWait(po);
    }

    /**
     * Starts a {@link Deployable} that is already deployed in the running container but that is
     * not servicing requests.
     *
     * @param deployable the {@link Deployable} to start
     */
    public void start(Deployable deployable)
    {
        TargetModuleID[] deployedAS = checkGetDeployedAs(deployable);
        ProgressObject po = this.manager.start(deployedAS);
        blockingWait(po);
    }

    /**
     * <p>Redeploy a {@link Deployable} already deployed to the running container. The service
     * becomes available for requests.
     * <p>Note that this method will be unsupported by the
     * {@link org.codehaus.cargo.container.deployer.Deployer}s based on the
     * {@link org.codehaus.cargo.container.spi.deployer.AbstractCopyingInstalledLocalDeployer}.
     * @param deployable the {@link Deployable} to redeploy
     * @see #deploy(Deployable)
     * @see #undeploy(Deployable)
     * @see DeploymentManager#redeploy
     */
    public void redeploy(Deployable deployable)
    {
        TargetModuleID[] deployedAS = checkGetDeployedAs(deployable);
        ProgressObject po = this.manager.redeploy(deployedAS, new File(deployable.getFile()), null);
        blockingWait(po);
    }

    /**
     * Stop a {@link Deployable} that is already deployed in the running container in order to
     * prevent it from servicing requests.
     *
     * @param deployable the {@link Deployable} to stop
     */
    public void stop(Deployable deployable)
    {
        TargetModuleID[] deployedAS = checkGetDeployedAs(deployable);
        ProgressObject po = this.manager.stop(deployedAS);
        blockingWait(po);
    }

    /**
     * Map the {@link TargetModuleID}s to the {@link Deployable}.
     * @param deployable a {@link Deployable} that is to be mapped.
     * @param targetModuleIDs {@link TargetModuleID}s corresponding to the {@link Deployable}
     * @see TargetModuleID
     */
    private void setDeployedAs(Deployable deployable, TargetModuleID[] targetModuleIDs)
    {
        this.deployedAs.put(deployable, targetModuleIDs);
    }


    /**
     * Check that the specified {@link Deployable} was deployed with this deployer and get its
     * {@link TargetModuleID}s.
     * @param deployable a {@link Deployable} to be checked.
     * @return An array of {@link TargetModuleID}s corresponding to the <code>deployable</code>.
     * @see TargetModuleID
     * @throws CargoException if the <code>deployable</code>
     * was never deployed with this deployer.
     */
    private TargetModuleID[] checkGetDeployedAs(Deployable deployable)
    {
        TargetModuleID[] deployedAs = (TargetModuleID[]) (this.deployedAs.get(deployable));

        if (null == deployedAs)
        {
            throw new CargoException("Cannot perform the requested operation with deployable ["
                + deployable.getFile() + "]. It seems to have never been deployed before.");
        }
        return deployedAs;
    }

    /**
     * This method performs a blocking wait until the specified {@link ProgressObject}
     * signals that it has finished running.
     * @param po a {@link ProgressObject} that will signal when the wait is to be finished.
     * @see ProgressObject
     * @throws CargoException  an exception is thrown if:
     * <ul><li><code>wait</code> was interrupted for any reason;</li><li><code>po</code>reported
     * that the operation was unsuccessfull.</li></ul>
     */
    private void blockingWait(ProgressObject po)
    {
        ProgressListener listener = new ProgressListener()
        {
            public synchronized void handleProgressEvent(ProgressEvent event)
            {
                if (!event.getDeploymentStatus().isRunning())
                {
                    this.notify();
                }
            }
        };

        boolean operationSuccessful = false;
        po.addProgressListener(listener);
        try
        {
            synchronized (listener)
            {
                listener.wait();
            }
            if (po.getDeploymentStatus().isCompleted())
            {
                operationSuccessful = true;
            }
        }
        catch (InterruptedException e)
        {
            //wait was interrupted => assume failure.
        }

        if (!operationSuccessful)
        {
            throw new CargoException(
                "Failure during " + po.getDeploymentStatus().getCommand().toString());
        }
    }


    /**
     * <p>Load {@link javax.enterprise.deploy.spi.factories.DeploymentFactory} implmentation from a
     * JAR file.
     * @param deployerJar JAR file containing the
     * {@link javax.enterprise.deploy.spi.factories.DeploymentFactory}
     * @param deployerClassPath extra classpath necessary for the <code>deployerJar</code> classes
     * to function normally (should NOT contain <code>deployerJar</code> itself!)
     *
     */
    public static void loadDeploymentFactorylFromJar(String deployerJar, URL[] deployerClassPath)
    {
        JarFile jar;
        try
        {
            jar = new JarFile(deployerJar);
        }
        catch (IOException e)
        {
            throw new CargoException("Could not access the JAR [" + deployerJar + "]", e);
        }

        String factoryClassName = null;
        try
        {
            factoryClassName = jar.getManifest().getMainAttributes().getValue(
                "J2EE-DeploymentFactory-Implementation-Class");

            URL[] extraClassPathAppended = new URL[deployerClassPath.length + 1];
            extraClassPathAppended[0] = new URL("file:///" + deployerJar);
            for (int i = 0; i < deployerClassPath.length; i++)
            {
                extraClassPathAppended[i + 1] = deployerClassPath[i];
            }

            ClassLoader myClassLoader = URLClassLoader.newInstance(extraClassPathAppended,
                Thread.currentThread().getContextClassLoader());

            Class factoryClass = myClassLoader.loadClass(factoryClassName);

            DeploymentFactory factory = (DeploymentFactory) factoryClass.newInstance();

            DeploymentFactoryManager factoryManager = DeploymentFactoryManager.getInstance();
            factoryManager.registerDeploymentFactory(factory);

        }
        catch (IOException e)
        {
            throw new CargoException("Could not acquire the manifest from the JAR file.", e);
        }
        catch (ClassNotFoundException e)
        {
            throw new CargoException("Could not find the DeploymentFactory class ["
                + factoryClassName + "].", e);
        }
        catch (InstantiationException e)
        {
            throw new CargoException("Could not instantiate the DeploymentFactory class ["
                + factoryClassName + "].", e);
        }
        catch (IllegalAccessException e)
        {
            throw new CargoException("Could not instantiate the DeploymentFactory class ["
                + factoryClassName + "].", e);
        }
    }

    /**
     * Acquires a {@link DeploymentManager}.
     *
     * @param uri URI to the JSR88-compliant container
     * @param username username to be used
     * @param password password to be used
     */
    private void initialize(String uri, String username, String password)
    {
        DeploymentFactoryManager factoryMgr = DeploymentFactoryManager.getInstance();
        try
        {
            this.manager = factoryMgr.getDeploymentManager(uri, username, password);
        }
        catch (DeploymentManagerCreationException e)
        {
            throw new CargoException("Could not acquire a DeploymentManager.", e);
        }
    }

    /**
     * Creates an array or {@link URL}s from a semicolon-delimited {@link String}.
     *
     * @param string source {@link String}
     * @return an array consisting of separate <code>string</code> entries appended to
     *         <code>"file:///"</code>.
     */
    private URL[] stringToURLArray(String string)
    {
        StringTokenizer tokenizer = new StringTokenizer(string, ";");
        URL[] classPathAsURLs = new URL[tokenizer.countTokens()];
        int currTokenNo = 0;
        while (tokenizer.hasMoreElements())
        {
            String currEntry = (String) tokenizer.nextElement();
            try
            {
                classPathAsURLs[ currTokenNo++ ] = new URL("file:///" + currEntry);
            }
            catch (MalformedURLException e)
            {
                // Cannot occur as the file:// prefix is hardcoded.
            }
        }
        return classPathAsURLs;
    }

}
