/* 
 * ========================================================================
 * 
 * Copyright 2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * ========================================================================
 */

package org.codehaus.cargo.module.customization;

import java.io.File;
import java.util.HashMap;

public class TestCustomization
{

    /**
     * Test file used for verification of the functionality
     * 
     * @version $Id: TestCustomization.java 978 2006-03-30 11:25:48Z vmassol $
     */
    public static void main(String[] args)
    {
        System.out.println("page");
        ZipCustomizationPack zcp = new ZipCustomizationPack();
        DirectoryCustomizationPack dcp = new DirectoryCustomizationPack();
        HashMap hm2 = new HashMap ();
        hm2.put("HIBERNATE", "page");
        //String key = new String ("WEB-INF/classes/hibernate.properties");
        String key = new String ("WEB-INF\\classes\\hibernate.properties");
        HashMap hm = new HashMap();
        hm.put(key, hm2);
        //zcp.update(new File("d:\\hibernaterecipe.war"), hm);
        dcp.update(new File("e:\\hb"), hm);

    }

}
