/* 
 * ========================================================================
 * 
 * Copyright 2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * ========================================================================
 */

package org.codehaus.cargo.module.customization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Update the files in directory 
 * 
 * @version $Id: DirectoryCustomizationPack.java 978 2006-03-30 11:25:48Z vmassol $
 *
 */
public class DirectoryCustomizationPack extends AbstractCustomizationPack
{
    public File update(File sourceDirectory, HashMap hm, File destinationFolder)
    {    	 
        if (!destinationFolder.isDirectory())
            throw new CustomizationException("The destination folder you specified " + destinationFolder.getAbsolutePath() + " is not a folder");                
        CopyAndUpdateAllFiles (sourceDirectory, hm, destinationFolder);		         
    	return destinationFolder;               
    }
    
    private void CopyAndUpdateAllFiles (File sourceDirectory, HashMap hm, File destinationFolder)
    {
        if (sourceDirectory.isDirectory())
        {
            if (!destinationFolder.exists())
                destinationFolder.mkdir();            
            String [] children = sourceDirectory.list();            
            //get the name of the file required to be updated from HashMap
            for (int i = 0; i < children.length; i++)
            {
                String file= children[i];
                CopyAndUpdateAllFiles(new File (sourceDirectory, file), hm, new File(destinationFolder, file));
            }
        }
        else {
            processSingleFile (sourceDirectory, hm, destinationFolder);
        }
    }
    
    private void processSingleFile (File sourceFile, HashMap hm, File destinationFile)
    {           
        for (Iterator it = hm.keySet().iterator(); it.hasNext();)
        {
            try{                
                String key = (String)it.next();
                FileOutputStream fos = new FileOutputStream (destinationFile);
                if (sourceFile.getAbsolutePath().endsWith(key))
                {
                    Reader reader = new ReplacingReader(new FileReader(sourceFile), (HashMap)hm.get(key));
                    char buffer[] = new char[1024];
                    OutputStreamWriter osw = new OutputStreamWriter(fos);
                    int len;
                    while ((len = reader.read(buffer)) > 0) {
                    osw.write(buffer, 0, len);
                    osw.flush();
                    }
                }
                else
                {
                    writeFile (new FileInputStream(sourceFile), fos);
                }
            }
            catch (IOException ioe)
            {
            }
            
        }
    }
    
    
    private void writeFile (InputStream fis, OutputStream fos) throws IOException
    {
    	byte[] buf = new byte[1024];
        int len;
        	while ((len = fis.read(buf)) > 0) {
        		fos.write(buf, 0, len);
        	}
        	fis.close();
            fos.close();
    }

}
