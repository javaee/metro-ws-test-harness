/* 
 * ========================================================================
 * 
 * Copyright 2004-2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * ========================================================================
 */
package org.codehaus.cargo.generic.deployable;

import org.codehaus.cargo.container.deployable.Deployable;
import org.codehaus.cargo.container.deployable.DeployableType;
import org.codehaus.cargo.container.deployable.EJB;
import org.codehaus.cargo.container.deployable.WAR;
import org.codehaus.cargo.container.deployable.EAR;
import org.codehaus.cargo.generic.spi.AbstractIntrospectionGenericHintFactory;

import java.lang.reflect.Constructor;

/**
 * Default deployable factory that returns deployables.
 *  
 * @version $Id: DefaultDeployableFactory.java 1160 2006-07-30 20:15:34Z vmassol $
 */
public class DefaultDeployableFactory extends AbstractIntrospectionGenericHintFactory 
    implements DeployableFactory
{
    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory.GenericParameters
     */
    private static class DeployableFactoryParameters implements GenericParameters
    {
        /**
         * The deployable file.
         */
        public String deployable;
    }
    
    /**
     * Register deployable classes mappings.
     */
    public DefaultDeployableFactory()
    {
        // Register default mappings
        registerDeployable("default", DeployableType.WAR, WAR.class);
        registerDeployable("default", DeployableType.EJB, EJB.class);
        registerDeployable("default", DeployableType.EAR, EAR.class);
        
        // Register container-specific mappings

        registerDeployable("tomcat5x", DeployableType.WAR,
            "org.codehaus.cargo.container.tomcat.TomcatWAR");

        registerDeployable("geronimo1x", DeployableType.WAR,
            "org.codehaus.cargo.container.geronimo.deployable.GeronimoWAR");
        registerDeployable("geronimo1x", DeployableType.EJB,
            "org.codehaus.cargo.container.geronimo.deployable.GeronimoEJB");
        registerDeployable("geronimo1x", DeployableType.EAR,
            "org.codehaus.cargo.container.geronimo.deployable.GeronimoEAR");

        // TODO: Register JBossWAR here when we add JBoss support
    }

    /**
     * {@inheritDoc}
     * @see DeployableFactory#registerDeployable(String, DeployableType, Class)
     */
    public void registerDeployable(String containerId, DeployableType type, Class deployableClass)
    {
        registerImplementation(containerId, type.getType(), deployableClass);
    }

    /**
     * Registers a deployable using a class specified as a String.
     *
     * @param containerId {@inheritDoc}
     * @param type {@inheritDoc}
     * @param deployableClassName the deployable implementation class to register as a String
     * @see #registerDeployable(String, DeployableType, Class)
     */
    public void registerDeployable(String containerId, DeployableType type,
        String deployableClassName)
    {
        registerImplementation(containerId, deployableClassName, type.getType()); 
    }
    
    /**
     * {@inheritDoc}
     * @see DeployableFactory#isDeployableRegistered(String, DeployableType)
     */
    public boolean isDeployableRegistered(String containerId, DeployableType type)
    {
        return hasMapping(containerId, type.getType());
    }

    /**
     * {@inheritDoc}
     * @see DeployableFactory#createDeployable(String, String, DeployableType)
     */
    public Deployable createDeployable(String containerId, String deployableLocation,
        DeployableType type)
    {
        Deployable deployable;

        DeployableFactoryParameters parameters = new DeployableFactoryParameters();
        parameters.deployable = deployableLocation;
        
        // First, try to locate a container-specific deployable mapping
        if (isDeployableRegistered(containerId, type))
        {
            deployable = (Deployable) createImplementation(
                containerId, type.getType(), parameters, "deployable");
        }
        else
        {
            // Use a default deployable
            deployable = (Deployable) createImplementation(
                "default", type.getType(), parameters, "deployable");
        }
        
        return deployable;
    }

    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory#getConstructor(Class, String, GenericParameters)
     */
    protected Constructor getConstructor(Class deployableClass, String hint,
        GenericParameters parameters) throws NoSuchMethodException
    {
        return deployableClass.getConstructor(new Class[] {String.class});
    }

    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory#createInstance
     */
    protected Object createInstance(Constructor constructor, String hint,
        GenericParameters parameters) throws Exception
    {
        String deployable = ((DeployableFactoryParameters) parameters).deployable;
        return constructor.newInstance(new Object[] {deployable});
    }
}
