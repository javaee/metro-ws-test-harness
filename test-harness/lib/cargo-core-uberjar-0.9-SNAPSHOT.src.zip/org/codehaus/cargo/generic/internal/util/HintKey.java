/* 
 * ========================================================================
 * 
 * Copyright 2005 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * ========================================================================
 */
package org.codehaus.cargo.generic.internal.util;

/**
 * Key used in {@link java.util.Map} for associating a container id and a hint.
 * 
 * @version $Id: HintKey.java 971 2006-03-27 13:37:28Z vmassol $
 */
public class HintKey
{
    /**
     * @see #getContainerId()
     */
    private String containerId;

    /**
     * @see #getHint()
     */
    private String hint;

    /**
     * @param containerId see {@link #containerId}
     * @param hint see {@link #hint}
     */
    public HintKey(String containerId, String hint)
    {
        this.containerId = containerId;
        this.hint = hint;
    }

    /**
     * @return the container id
     */
    public String getContainerId()
    {
        return this.containerId;
    }

    /**
     * @return the additional string which makes the association unique. For example for
     *         configurations a container can have several possible configurations associated with
     *         it. Example of hints: "standalone", "existing", "mycusyomconfig"
     */
    public String getHint()
    {
        return this.hint;
    }

    /**
     * Differentiate two keys. Needed as we're using this class as an index in a Map.
     * {@inheritDoc}
     * @see Object#equals(java.lang.Object)
     */
    public boolean equals(Object hintKey)
    {
        boolean result = false;

        if ((hintKey != null) && (hintKey instanceof HintKey))
        {
            HintKey key = (HintKey) hintKey;
            if (key.getContainerId().equals(getContainerId())
                && key.getHint().equals(getHint()))
            {
                result = true;
            }
        }

        return result;
    }

    /**
     * Allows quick verification to check is two keys are different. Needed as we're using 
     * this class as an index in a Map.
     * {@inheritDoc}
     * @see Object#hashCode()
     */
    public int hashCode()
    {
        return (getContainerId() + getHint()).hashCode();
    }
}
