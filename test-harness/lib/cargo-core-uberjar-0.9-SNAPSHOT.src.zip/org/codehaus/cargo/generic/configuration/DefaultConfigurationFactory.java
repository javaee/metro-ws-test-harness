/* 
 * ========================================================================
 * 
 * Copyright 2004-2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * ========================================================================
 */
package org.codehaus.cargo.generic.configuration;

import org.codehaus.cargo.container.ContainerException;
import org.codehaus.cargo.container.configuration.Configuration;
import org.codehaus.cargo.container.configuration.ConfigurationType;
import org.codehaus.cargo.generic.spi.AbstractIntrospectionGenericHintFactory;
import org.codehaus.cargo.util.FileHandler;
import org.codehaus.cargo.util.DefaultFileHandler;

import java.lang.reflect.Constructor;

/**
 * Default {@link ConfigurationFactory} implementation that has all the known container 
 * configurations registered against their containers. It also supports registering new
 * configurations against any container.
 * 
 * @version $Id: DefaultConfigurationFactory.java 1160 2006-07-30 20:15:34Z vmassol $
 */
public class DefaultConfigurationFactory extends AbstractIntrospectionGenericHintFactory
    implements ConfigurationFactory
{
    /**
     * File utility class.
     */
    private FileHandler fileHandler = new DefaultFileHandler();

    /**
     * @see GenericParameters
     */
    private static class ConfigurationFactoryParameters implements GenericParameters
    {
        /**
         * The home directory for the configuration.
         */
        public String home;
    }
    
    /**
     * Register default configurations.
     */
    public DefaultConfigurationFactory()
    {
        super();

        // Note: Sorted by container id alphabetical order

        registerConfiguration("geronimo1x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.geronimo.Geronimo1xStandaloneLocalConfiguration");
        registerConfiguration("geronimo1x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.geronimo.Geronimo1xExistingLocalConfiguration");

        registerConfiguration("jboss3x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jboss.JBossStandaloneLocalConfiguration");
        registerConfiguration("jboss3x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.jboss.JBossExistingLocalConfiguration");
        registerConfiguration("jboss4x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jboss.JBossStandaloneLocalConfiguration");
        registerConfiguration("jboss4x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.jboss.JBossExistingLocalConfiguration");
        registerConfiguration("jboss4x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.jboss.JBossRuntimeConfiguration");

        registerConfiguration("jetty4x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jetty.Jetty4xEmbeddedStandaloneLocalConfiguration");
        registerConfiguration("jetty5x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jetty.Jetty5xEmbeddedStandaloneLocalConfiguration");
        registerConfiguration("jetty6x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jetty.Jetty6xEmbeddedStandaloneLocalConfiguration");

        registerConfiguration("jo1x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jo.Jo1xStandaloneLocalConfiguration");
        
        registerConfiguration("orion1x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.orion.OrionStandaloneLocalConfiguration");
        registerConfiguration("orion2x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.orion.OrionStandaloneLocalConfiguration");
        registerConfiguration("oc4j9x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.orion.Oc4j9xStandaloneLocalConfiguration");

        registerConfiguration("resin2x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.resin.Resin2xStandaloneLocalConfiguration");
        registerConfiguration("resin2x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.resin.ResinExistingLocalConfiguration");
        registerConfiguration("resin3x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.resin.Resin3xStandaloneLocalConfiguration");
        registerConfiguration("resin3x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.resin.ResinExistingLocalConfiguration");
        
        registerConfiguration("tomcat3x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.tomcat.Tomcat3xStandaloneLocalConfiguration");
        registerConfiguration("tomcat4x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.tomcat.Tomcat4xStandaloneLocalConfiguration");
        registerConfiguration("tomcat4x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.tomcat.TomcatExistingLocalConfiguration");
        registerConfiguration("tomcat4x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.tomcat.TomcatRuntimeConfiguration");
        registerConfiguration("tomcat5x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.tomcat.Tomcat5xStandaloneLocalConfiguration");
        registerConfiguration("tomcat5x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.tomcat.TomcatExistingLocalConfiguration");
        registerConfiguration("tomcat5x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.tomcat.TomcatRuntimeConfiguration");

        registerConfiguration("weblogic8x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.weblogic.WebLogicStandaloneLocalConfiguration");
        registerConfiguration("weblogic8x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.weblogic.WebLogicExistingLocalConfiguration");
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationFactory#isConfigurationRegistered(String, ConfigurationType)
     */
    public boolean isConfigurationRegistered(String containerId, ConfigurationType type)
    {
        return hasMapping(containerId, type.getType());
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationFactory#registerConfiguration(String, ConfigurationType, Class)
     */
    public void registerConfiguration(String containerId, ConfigurationType type,
        Class configurationClass)
    {
        registerImplementation(containerId, type.getType(), configurationClass);
    }

    /**
     * Registers a configuration using a class specified as a String.
     *
     * @param containerId {@inheritDoc}
     * @param type {@inheritDoc}
     * @param configurationClassName the configuration implementation class to register as a String
     * @see #registerConfiguration(String, ConfigurationType, Class)
     */
    public void registerConfiguration(String containerId, ConfigurationType type,
        String configurationClassName)
    {
        registerImplementation(containerId, configurationClassName, type.getType());
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationFactory#getConfigurationClass(String, org.codehaus.cargo.container.configuration.ConfigurationType)
     */
    public Class getConfigurationClass(String containerId, ConfigurationType type)
    {
        return getMapping(containerId, type.getType());
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationFactory#createConfiguration(String, ConfigurationType)
     */
    public Configuration createConfiguration(String containerId, ConfigurationType type)
    {
        return createConfiguration(containerId, type, null);
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationFactory#createConfiguration(String, org.codehaus.cargo.container.configuration.ConfigurationType, String)
     */
    public Configuration createConfiguration(String containerId, ConfigurationType type,
        String home)
    {
        ConfigurationFactoryParameters parameters = new ConfigurationFactoryParameters();
        parameters.home = home;
        
        return (Configuration) createImplementation(containerId, type.getType(), parameters,
            "configuration");
    }

    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory#getConstructor(Class, String, GenericParameters)
     */
    protected Constructor getConstructor(Class configurationClass, String hint,
        GenericParameters parameters) throws NoSuchMethodException
    {
        Constructor constructor;
        
        // Runtime configurations have constructors that do not take any parameter.
        if (ConfigurationType.toType(hint) == ConfigurationType.RUNTIME)
        {
            constructor = configurationClass.getConstructor(new Class[] {});
        }
        else if ((ConfigurationType.toType(hint) == ConfigurationType.EXISTING) 
            || (ConfigurationType.toType(hint) == ConfigurationType.STANDALONE))
        {
            constructor = configurationClass.getConstructor(new Class[] {String.class});
        }
        else
        {
            throw new ContainerException("Unknown configuration type [" + hint + "]");
        }
        
        return constructor; 
    }

    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory#createInstance
     */
    protected Object createInstance(Constructor constructor, String hint,
        GenericParameters parameters) throws Exception
    {
        Object instance;

        String home = ((ConfigurationFactoryParameters) parameters).home;

        // Runtime configurations have constructors that do not take any parameter.
        if (ConfigurationType.toType(hint) == ConfigurationType.RUNTIME)
        {
            if (home != null)
            {
                throw new ContainerException("The configuration home parameter should not be "
                    + "specified for runtime configurations");
            }
            
            instance = constructor.newInstance(new Object[] {});
        }
        else if ((ConfigurationType.toType(hint) == ConfigurationType.EXISTING) 
            || (ConfigurationType.toType(hint) == ConfigurationType.STANDALONE))
        {
            if (home == null)
            {
                // The user has not specified a home directory for the configuration, create one
                // in the temporary directory if it's a standalone configuration
                if (ConfigurationType.toType(hint) == ConfigurationType.EXISTING)
                {
                    throw new ContainerException("The configuration home parameter must be "
                        + "specified for existing configurations");
                }
                else
                {
                    home = this.fileHandler.getTmpPath("conf");
                }
            }

            instance = constructor.newInstance(new Object[] {home}); 
        }
        else
        {
            throw new ContainerException("Unknown configuration type [" + hint + "]");
        }
        
        return instance; 
    }
}
