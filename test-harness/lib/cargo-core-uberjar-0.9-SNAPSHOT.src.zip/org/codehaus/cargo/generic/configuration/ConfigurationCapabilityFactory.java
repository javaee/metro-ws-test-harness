/*
 * ========================================================================
 *
 * Copyright 2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ========================================================================
 */
package org.codehaus.cargo.generic.configuration;

import org.codehaus.cargo.container.configuration.ConfigurationType;
import org.codehaus.cargo.container.configuration.ConfigurationCapability;

/**
 * Allow finding a Configuration's capability by container id and type.
 *
 * @version $Id: ConfigurationCapabilityFactory.java 971 2006-03-27 13:37:28Z vmassol $
 */
public interface ConfigurationCapabilityFactory
{
    /**
     * @param containerId the id of the container to register against
     * @param type the configuration type under which the capability should be registered
     * @param configurationCapabilityClass the configuration capability implementation class to
     *        register
     */
    void registerConfigurationCapability(String containerId, ConfigurationType type,
        Class configurationCapabilityClass);

    /**
     * Create a {@link org.codehaus.cargo.container.configuration.ConfigurationCapability} instance.
     *
     * @param containerId the container id associated with the configuration capability
     * @param type the configuration type associated with the capability
     * @return the configuration capability instance matching the parameter passed
     */
    ConfigurationCapability createConfigurationCapability(String containerId,
        ConfigurationType type);
}
