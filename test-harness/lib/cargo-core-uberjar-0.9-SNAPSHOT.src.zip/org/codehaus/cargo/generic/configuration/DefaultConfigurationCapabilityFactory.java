/*
 * ========================================================================
 *
 * Copyright 2006 Vincent Massol.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ========================================================================
 */
package org.codehaus.cargo.generic.configuration;

import org.codehaus.cargo.generic.spi.AbstractIntrospectionGenericHintFactory;
import org.codehaus.cargo.container.configuration.ConfigurationType;
import org.codehaus.cargo.container.configuration.ConfigurationCapability;

import java.lang.reflect.Constructor;

/**
 * Default implementation of {@link ConfigurationCapabilityFactory}.
 * Registers all known configuration capabilities.
 *
 * @version $Id: DefaultConfigurationCapabilityFactory.java 990 2006-04-06 16:28:29Z vmassol $
 */
public class DefaultConfigurationCapabilityFactory extends AbstractIntrospectionGenericHintFactory
    implements ConfigurationCapabilityFactory
{
    /**
     * Initialize configuration capability name mappings with container ids and configuration types.
     */
    public DefaultConfigurationCapabilityFactory()
    {
        super();

        // Note: We register configuration capabilities using introspection so that we don't have to
        // depend on those classes at build time nor at runtime. More specifically this allows a
        // user to use the generic API and choose what container implementation jar he wants to use
        // without having to add all container implementations jars in the classpath.

        // Note: Sorted by container id alphabetical order

        registerConfigurationCapability("geronimo1x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.geronimo.internal."
                + "GeronimoStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("geronimo1x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.geronimo.internal."
                + "GeronimoExistingLocalConfigurationCapability");

        registerConfigurationCapability("jboss3x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jboss.internal."
                + "JBossStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("jboss3x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.jboss.internal."
                + "JBossExistingLocalConfigurationCapability");
        registerConfigurationCapability("jboss3x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.jboss.internal."
                + "JBossRuntimeConfigurationCapability");
        registerConfigurationCapability("jboss4x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jboss.internal."
                + "JBossStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("jboss4x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.jboss.internal."
                + "JBossExistingLocalConfigurationCapability");
        registerConfigurationCapability("jboss4x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.jboss.internal."
                + "JBossRuntimeConfigurationCapability");

        registerConfigurationCapability("jetty4x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jetty.internal."
                + "Jetty4xStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("jetty5x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jetty.internal."
                + "Jetty5xStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("jetty6x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jetty.internal."
                + "Jetty6xStandaloneLocalConfigurationCapability");

        registerConfigurationCapability("jo1x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.jo.internal."
                + "Jo1xStandaloneLocalConfigurationCapability");

        registerConfigurationCapability("orion1x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.orion.internal."
                + "OrionStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("orion2x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.orion.internal."
                + "OrionStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("oc4j9x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.orion.internal."
                + "OrionStandaloneLocalConfigurationCapability");

        registerConfigurationCapability("resin2x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.resin.internal."
                + "ResinStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("resin2x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.resin.internal."
                + "ResinExistingLocalConfigurationCapability");
        registerConfigurationCapability("resin3x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.resin.internal."
                + "ResinStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("resin3x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.resin.internal."
                + "ResinExistingLocalConfigurationCapability");

        registerConfigurationCapability("tomcat3x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("tomcat4x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("tomcat4x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatExistingLocalConfigurationCapability");
        registerConfigurationCapability("tomcat4x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatRuntimeConfigurationCapability");
        registerConfigurationCapability("tomcat5x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("tomcat5x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatExistingLocalConfigurationCapability");
        registerConfigurationCapability("tomcat5x", ConfigurationType.RUNTIME,
            "org.codehaus.cargo.container.tomcat.internal."
                + "TomcatRuntimeConfigurationCapability");

        registerConfigurationCapability("weblogic8x", ConfigurationType.STANDALONE,
            "org.codehaus.cargo.container.weblogic.internal."
                + "WebLogicStandaloneLocalConfigurationCapability");
        registerConfigurationCapability("weblogic8x", ConfigurationType.EXISTING,
            "org.codehaus.cargo.container.weblogic.internal."
                + "WebLogicExistingLocalConfigurationCapability");
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationCapabilityFactory#registerConfigurationCapability(String, org.codehaus.cargo.container.configuration.ConfigurationType, Class)
     */
    public void registerConfigurationCapability(String containerId, ConfigurationType type,
        Class configurationCapabilityClass)
    {
        registerImplementation(containerId, type.getType(), configurationCapabilityClass);
    }

    /**
     * Registers a configuration capability using a class specified as a String.
     *
     * @param containerId {@inheritDoc}
     * @param type {@inheritDoc}
     * @param configurationCapabilityClass the configuration capability implementation class to
     *        register as a String
     * @see #registerConfigurationCapability(String, org.codehaus.cargo.container.configuration.ConfigurationType, Class)
     */
    public void registerConfigurationCapability(String containerId, ConfigurationType type,
        String configurationCapabilityClass)
    {
        registerImplementation(containerId, configurationCapabilityClass, type.getType());
    }

    /**
     * {@inheritDoc}
     * @see ConfigurationCapabilityFactory#createConfigurationCapability(String, org.codehaus.cargo.container.configuration.ConfigurationType)
     */
    public ConfigurationCapability createConfigurationCapability(String containerId,
        ConfigurationType type)
    {
        return (ConfigurationCapability) createImplementation(containerId, type.getType(), null,
            "configuration capability");
    }

    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory#getConstructor(Class, String, org.codehaus.cargo.generic.spi.AbstractGenericHintFactory.GenericParameters)
     */
    protected Constructor getConstructor(Class configurationCapabilityClass, String hint,
        GenericParameters parameters) throws NoSuchMethodException
    {
        return configurationCapabilityClass.getConstructor(null);
    }

    /**
     * {@inheritDoc}
     * @see org.codehaus.cargo.generic.spi.AbstractGenericHintFactory#createInstance
     */
    protected Object createInstance(Constructor constructor, String hint,
        GenericParameters parameters) throws Exception
    {
        return constructor.newInstance(null);
    }
}
