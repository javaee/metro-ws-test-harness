When MAVEN is used to build this product (as is recommended), the contents
of the MANIFEST.MF file in this directory is ignored; maven builds its own
version. This file is only relevant when building this project using ant
or some other build tool.
