Please download http://www.ibiblio.org/maven/commons-logging/jars/commons-logging-1.1.jar and http://www.ibiblio.org/maven/junit/jars/junit-3.8.1.jar into this directory. 
